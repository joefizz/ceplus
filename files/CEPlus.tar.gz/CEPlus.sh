#!/usr/bin/bash

# Hello world script program

print "Be Secure with Cyber Essentials";
